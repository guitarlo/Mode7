<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="2021.03.23" name="map2" tilewidth="32" tileheight="32" tilecount="70" columns="10">
 <image source="grass.png" width="320" height="224"/>
</tileset>
